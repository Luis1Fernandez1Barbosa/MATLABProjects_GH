% Problema 2.- 

%a)intercambie variables a,b usando var.adicional=t             
a=input('a= ');
b=input('b= ');
t=a;
a=b;
b=t;
a
b
               
% b)intercambie variables a,b sin var.adicional                
a=input('a= ');
b=input('b= ');
a=a+b;
b=a-b;
a=a-b;
a
b
  